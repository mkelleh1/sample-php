@extends('layouts.app')
@section('title', 'Error')

@section('content')
    <div class="content-minify">
        <div class="container">
            <div class="error-page">
                <div class="text-center">
                    <h1>Error 404!</h1>
                    <h2>Page not found</h2>
                </div>

            </div>
        </div>
    </div>
@stop