<?php

/*
|--------------------------------------------------------------------------
| Web Routes for home page
|--------------------------------------------------------------------------
*/
Route::get('/home', 'HomeController@index');
Route::get('/', 'HomeController@index');


/*
|--------------------------------------------------------------------------
| Routes to minify css code.
|--------------------------------------------------------------------------
*/
Route::get('/spinner', 'HomeController@index');
Route::post('/spinner', 'HomeController@spinner');


/*
|--------------------------------------------------------------------------
| This route will display about page
|--------------------------------------------------------------------------
*/
Route::get('/about', function (){
    return view('about');
});



/*
|--------------------------------------------------------------------------
| Web routes to manage contact page
|--------------------------------------------------------------------------
*/
Route::get('/contact', function (){
    return view('contact');
});
Route::post('/contact', 'HomeController@contact');


Route::get('captcha-form-validation',array('as'=>'google.get-recaptcha-validation-form','uses'=>'FileController@getCaptchaForm')) ;
Route::post('captcha-form-validation',array('as'=>'google.post-recaptcha-validation','uses'=>'FileController@postCaptchaForm')) ;


/*
|--------------------------------------------------------------------------
| This route will display an error page
|--------------------------------------------------------------------------
*/
Route::get('error', function (){
    return view('404');
});


/*
|--------------------------------------------------------------------------
| Redirect all non existing page to error page
|--------------------------------------------------------------------------
*/
Route::any('{catchall}', function() {
    return redirect('/error');
})->where('catchall', '.*');