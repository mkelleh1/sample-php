<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mikemike\Spinner\Spinner;
use Illuminate\Support\Facades\Mail;

class HomeController extends Controller
{

    /**
     * |--------------------------------------------------------------------------
     * | Home page function
     * |--------------------------------------------------------------------------*/
    public function index()
    {
        return view('home');
    }
    

    /**
     * |--------------------------------------------------------------------------
     * | Send Contact email
     * |--------------------------------------------------------------------------*/
    public function contact(Request $request)
    {
        Mail::send('mails.contact', ['request' => $request], function ($message) use ($request) {
            $message->from('no-reply@gmail.com', "Minify");
            $message->subject('Contact form submitted');
            $message->to('nd_sohail@yahoo.com');
        });

        return redirect()->back()->withMessage('Email sent we will get back to you');
    }


    public function spinner(Request $request)
    {
        $customMessages = [
            'g-recaptcha-response.required' => 'Please check the captcha box.',
        ];
        $this->validate($request, [
            'g-recaptcha-response'=>'required|captcha',
            'content_text' => 'required',
        ], $customMessages);


        $file = file(storage_path('app/db.sdata'));
        $data = $request->content_text;


        foreach ($file as $line)
        {
            $synonyms = explode('|', $line);
            foreach ($synonyms as $word)
            {
                $word = trim($word);
                if ($word != '')
                {
                    $word = str_replace('/', '\/', $word);
                    if (preg_match('/\b' . $word . '\b/i', $data))
                    {
                        $founds[md5($word)] = str_replace(array("\n", "\r"), '', $line);
                        $data = preg_replace('/\b' . $word . '\b/i', md5($word), $data);
                    }
                }
            }
        }

        $array_count = count($founds);
        if ($array_count != 0) {
            foreach ($founds as $code => $value) {
                $data = str_replace($code, '{' . $value . '}', $data);
            }
        }

        $spinner = new Spinner();
        $spin = $spinner->process($data);
        return redirect()->back()->withSpinned($spin)->withContent($request->content_text);
}
    
}
