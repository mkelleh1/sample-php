<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?> | Minify and compress CSS, JS and HTML files</title>

    <!-- Styles -->
    <link href="<?php echo e(asset('plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('plugins/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="icon" href="<?php echo e(asset('images/fav.png')); ?>" type="image/x-icon"/>
</head>
<body>
<!--Navigation bar-->
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navigation">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Code <strong>Minifier</strong></a>
        </div>

        <div class="collapse navbar-collapse" id="navigation">
            <ul class="nav navbar-nav navbar-right">
                <li class="css"><a href="<?php echo e(url('css-minify')); ?>">Minify CSS</a></li>
                <li class="js"><a href="<?php echo e(url('js-minify')); ?>">Minify JS</a></li>
                <li class="html"><a href="<?php echo e(url('html-minify')); ?>">Minify HTML</a></li>
                <li class="about"><a href="<?php echo e(url('about')); ?>">About</a></li>
                <li class="contact"><a href="<?php echo e(url('contact')); ?>">Contact</a></li>
            </ul>
        </div>
    </div>
</nav>

<!--Page content-->
<div id="app">
    <?php echo $__env->yieldContent('content'); ?>
</div>

<!--Page footer-->
<footer>
    <div class="container">
        <p>© Code Minifier by <a href="http://aamish.net/" target="_blank"><span>@</span>aamish</a> For more, check out <a href="http://aamish.net/" target="_blank">aamish.net</a></p>
    </div>
</footer>

<!-- Scripts -->
<script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/typed/dist/typed.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>
