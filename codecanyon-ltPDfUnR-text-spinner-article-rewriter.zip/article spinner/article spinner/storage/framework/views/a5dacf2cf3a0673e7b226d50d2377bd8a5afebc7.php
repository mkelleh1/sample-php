<?php $__env->startSection('title', 'Error'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-minify">
        <div class="container">
            <div class="error-page">
                <div class="text-center">
                    <h1>Error 404!</h1>
                    <h2>Page not found</h2>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>