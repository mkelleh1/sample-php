<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

    <div class="content-spin">
        <div class="container">
            <div class="text-center">
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo">
            </div>
            <br>
            <p class="text-center">The most dependable way to win over major search engines is by loading your site with a continuous flow of unique, readable, useful content. This is why Article Spinner represents a potential gold mine for you and your search engine marketing efforts.
            </p>

        </div>
        <div class="container">
            <form action="<?php echo e(url('spinner')); ?>" method="post">


                <div class="row">
                    <!--un-minified css code-->
                    <div class="col-sm-12">
                        <?php if(count($errors->all())): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong>Alert!</strong> <?php echo e($error); ?>

                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h3 class="panel-title">Input Text</h3>
                            </div>
                            <div class="panel-body">
                                <?php if(Session::has('spinned')): ?>
                                    <textarea name="content_text" class="minified_output" required><?php echo e(Session::get('spinned')); ?></textarea>
                                <?php else: ?>
                                    <textarea name="content_text" autofocus required placeholder="Paste text here"><?php echo e(old('content_text')); ?></textarea>
                                <?php endif; ?>
                            </div>

                        </div>

                        <div class="submit-btn">
                            <div class="text-action">
                                <div class="g-recaptcha" data-sitekey="6LdIOykUAAAAADCrgqWrvty50NDkUGhi1Gax3GOK"></div>
                                <button type="submit" class="btn btn-primary">Rewrite Article</button>
                            </div>
                        </div>
                    </div>

                </div>
            </form>
        </div>
    </div>


    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <div class="content-box">
                        <img src="<?php echo e(asset('images/s1.png')); ?>" alt="feature">
                        <h2>Responsive Layout</h2>
                        <p>Powerful Layout with Responsive functionality that can be adapted to any screen size. Resize browser to view.</p>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="content-box">
                        <img src="<?php echo e(asset('images/s4.png')); ?>" alt="feature">
                        <h2>Cross Browser</h2>
                        <p>Article rewriter is responsive and compatible to all the latest browsers, an Optimal experience for your users.</p>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="content-box">
                        <img src="<?php echo e(asset('images/s5.png')); ?>" alt="feature">
                        <h2>Powerful Performance</h2>
                        <p>It includes tons of optimized css code that are completely customizable and deliver unmatched fast performance.</p>
                    </div>
                </div>
            </div>
            <hr>
            <div class="bottom-content">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce in augue quis nisi aliquam viverra vel vitae massa. Sed nulla ex, feugiat ut laoreet a, aliquam et eros. Suspendisse sit amet pretium dui. Cras ac odio efficitur, mattis justo in, bibendum risus. Phasellus non ornare tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus dui elit, euismod id vehicula ac, laoreet sit amet quam. Aliquam fringilla augue non risus efficitur, sed imperdiet nunc congue. Duis finibus luctus tellus. Ut vitae quam enim. Proin cursus imperdiet nibh, vitae gravida massa vulputate nec. Donec sed ex ut urna eleifend rutrum. Integer consectetur vel ante ac bibendum. Mauris mattis aliquam iaculis. Sed nunc elit, convallis eget dui sed, interdum pharetra magna. Nam vitae aliquam arcu, sed ornare nisi.</p>
                <p>Sed et nisl eu odio dictum luctus id maximus nulla. Nam non lectus sit amet est dignissim vulputate lobortis non sapien. Quisque scelerisque augue ac nunc consequat, ut rutrum metus convallis. Duis a sodales nisl, ut pharetra quam. Cras eget interdum arcu. Duis lacus augue, auctor et est nec, ultrices tempus ipsum. Maecenas dignissim ex eget odio porta, non rutrum ligula pretium. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed tincidunt turpis sed augue dignissim, interdum viverra mauris ultricies. Donec condimentum, mauris vitae rutrum aliquet, elit leo scelerisque lacus, a pretium purus nunc in quam. Pellentesque vitae turpis finibus, auctor erat a, vulputate massa.</p>
                <p>Quisque sed imperdiet nunc. Nullam non ex eu nisi finibus molestie. Etiam nec massa dui. Nunc varius, nibh vitae ultrices rhoncus, quam nibh pretium felis, eget tincidunt metus velit ut nisl. Sed interdum tellus vel odio tempus, non ullamcorper enim tincidunt. Pellentesque convallis, eros vel pellentesque condimentum, dolor lorem scelerisque nibh, sit amet consequat urna ligula eu erat. Nullam convallis vel est a sagittis. Suspendisse mattis ex tempor, mattis leo id, bibendum ex. Cras gravida, ante nec auctor aliquam, purus dolor condimentum ipsum, eu lacinia metus quam vel augue. Nunc tristique, metus sed malesuada imperdiet, elit urna ultricies lorem, quis ultricies leo massa viverra felis. Pellentesque volutpat cursus lectus, vitae convallis lectus aliquam ut. Nullam lacinia mauris leo, sit amet cursus augue pretium a. Morbi volutpat suscipit ante eu molestie. Curabitur non quam nunc.</p>
                <p>Nunc quis nibh ac neque feugiat gravida sed vel diam. Integer lacinia odio et tempor mollis. Vestibulum placerat enim a ullamcorper dignissim. Sed metus orci, condimentum a cursus ut, rhoncus viverra mi. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Maecenas sodales lorem et dolor bibendum maximus. Maecenas arcu purus, sagittis eget tincidunt vel, rhoncus sodales nisi. Mauris sodales ex tortor, ut mattis lectus rutrum pretium. Vestibulum leo quam, elementum sit amet lorem a, tristique varius urna. Integer vehicula, turpis et lacinia ultrices, lacus quam condimentum erat, eget dapibus neque purus vitae odio. Sed malesuada arcu vel dui ornare commodo. Duis augue ante, laoreet et dictum sit amet, egestas in eros. Nam condimentum dui tellus, vel sodales est suscipit et. Nunc vehicula diam ut lacus faucibus lobortis nec ut urna.</p>
                <p>Phasellus tempor sem sit amet risus placerat, nec venenatis justo dignissim. Nullam consectetur magna sed libero fermentum, et porttitor augue pharetra. Duis pellentesque dui et eros laoreet volutpat. Cras fermentum tellus ut justo cursus, ut vestibulum nibh blandit. Aenean cursus risus sem, sit amet faucibus nisl tincidunt eu. Donec a euismod arcu, vitae fermentum lectus. Fusce convallis est id ipsum malesuada interdum. Mauris elementum consectetur quam, sit amet dignissim ex dignissim eget.</p>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>