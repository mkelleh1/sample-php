
<html>
<head>
</head>
<body style="margin: 0px;">

<div style="float: left; width: 100%; background: #FFF;">

    <div style="float: left; background-color: #00BC8C; margin-bottom: 15px; text-align: center; width: 100%;">
        <h4 style="font-size: 17px; padding: 15px 5px; text-align: center; margin: 10px; color:#FFF;">Code Minify</h4>
    </div>

    <div style="float: left; color: #333; width: 100%">
        <p style="line-height: 30px; font-size: 14px; text-align: left; margin: 10px;">Contact page Submitted by <?php echo e($request->name); ?></p>
    </div>
    <p>Email: <?php echo e($request->email); ?></p>
    <p>Message: <?php echo e($request->message); ?></p>

    <div style="width:100%; float:left; padding: 8px 0;">
        <p style="font-size: 14px">© Code Minifier by <a href="http://aamish.net/" target="_blank"><span>@</span>aamish</a> For more, check out <a href="http://aamish.net/" target="_blank">aamish.net</a></p>
    </div>
</div>

</body>
</html>