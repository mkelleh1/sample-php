<?php $__env->startSection('title', 'Minify Javascript'); ?>

<?php $__env->startSection('content'); ?>

    <div class="content-minify">
        <div class="container">
            <h2 class="text-center">Minify Javascript</h2>
            <p class="text-center">The sole benefit of minified JavaScript code is allowing a client to download fewer bytes, enabling the page to load faster, use less battery, use less of a mobile data plan, etc. This is usually be done as a build step when releasing code to a web server.
            </p>
            <div class="row">
                <!--un-minified css code-->
                <div class="col-sm-6">
                    <form action="<?php echo e(url('js-minify')); ?>" method="post">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="panel panel-success">
                            <div class="panel-heading">
                                <h3 class="panel-title">Input JS</h3>
                            </div>
                            <div class="panel-body">
                                <?php if(Session::has('content')): ?>
                                    <textarea name="content_js" required><?php echo e(Session::get('content')); ?></textarea>
                                <?php else: ?>
                                    <textarea name="content_js" autofocus required placeholder="Paste JS code here"></textarea>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="text-right">
                            <button type="submit" class="btn btn-success">Minify</button>
                        </div>
                    </form>
                </div>

                <!--minified css code-->
                <div class="col-sm-6">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <h3 class="panel-title">Minified Output</h3>
                        </div>
                        <div class="panel-body">
                            <?php if(Session::has('minified')): ?>
                                <textarea class="minified_output" placeholder="minified code"><?php echo e(Session::get('minified')); ?></textarea>
                                <?php else: ?>
                                <textarea placeholder="minified code"></textarea>
                            <?php endif; ?>


</div>
</div>
<div class="text-right">
<button type="submit" class="btn btn-success select_text">Select All</button>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
$(function () {
$('.navbar-nav>li').removeClass('active');
$('.navbar-nav>li.js').addClass('active');
})
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>