<?php $__env->startSection('title', 'About'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-minify">
        <div class="container">
            <h2 class="text-center">About Page</h2>
            <p class="text-center">Sed ullamcorper porta dictum. Integer a enim arcu. Fusce tellus justo, commodo at iaculis ut, faucibus eu arcu. Sed ut bibendum diam. Vivamus semper massa in lobortis ornare. Integer sed arcu accumsan, aliquet urna sagittis, rhoncus eros</p>
            <br><br>

            <div class="row">
                <div class="col-sm-6">
                    <div class="about-image">
                        <img src="<?php echo e(asset('images/about2.jpg')); ?>" class="img-responsive" alt="">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="about-text">
                        <p>
                            Sed maximus pharetra molestie. Donec laoreet enim sed ex auctor pretium. Phasellus eget auctor nisl. Praesent molestie at lorem in tempus. Morbi mattis vulputate rhoncus. Vivamus rutrum fringilla erat, tempor sodales ante malesuada nec. Aliquam ultricies urna ut massa imperdiet, interdum pellentesque enim tristique. Curabitur vehicula elit nisl, sed molestie felis eleifend laoreet. Aliquam erat volutpat. Aliquam ac mauris efficitur, facilisis quam eu, vehicula massa. Nulla vitae nisi ullamcorper purus finibus efficitur sit amet et ligula. Nullam porta egestas elit, eu tincidunt sem accumsan ut. Nulla in pellentesque nisl. Aenean sed tortor in risus scelerisque placerat.
                        </p>
                        <p>diam eget feugiat vestibulum, ex metus tincidunt turpis, sed euismod urna turpis vitae dui. Pellentesque sit amet metus vestibulum, rhoncus velit vitae, placerat nibh. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin nec euismod est, a consectetur metus.</p>
                    </div>
                </div>
            </div>
            <br>
            <hr>
            <br>

            <div class="row">

                <div class="col-sm-6">
                    <div class="about-text">
                        <p>
                            Sed maximus pharetra molestie. Donec laoreet enim sed ex auctor pretium. Phasellus eget auctor nisl. Praesent molestie at lorem in tempus. Morbi mattis vulputate rhoncus. Vivamus rutrum fringilla erat, tempor sodales ante malesuada nec. Aliquam ultricies urna ut massa imperdiet, interdum pellentesque enim tristique. Curabitur vehicula elit nisl, sed molestie felis eleifend laoreet. Aliquam erat volutpat. Aliquam ac mauris efficitur, facilisis quam eu, vehicula massa. Nulla vitae nisi ullamcorper purus finibus efficitur sit amet et ligula. Nullam porta egestas elit, eu tincidunt sem accumsan ut. Nulla in pellentesque nisl. Aenean sed tortor in risus scelerisque placerat.
                        </p>
                        <p>
                            diam eget feugiat vestibulum, ex metus tincidunt turpis, sed euismod urna turpis vitae dui. Pellentesque sit amet metus vestibulum, rhoncus velit vitae, placerat nibh. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin nec euismod est, a consectetur metus.
                        </p>
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="about-image">
                        <img src="<?php echo e(asset('images/about1.jpg')); ?>" class="img-responsive" alt="">
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(function () {
            $('.navbar-nav>li').removeClass('active');
            $('.navbar-nav>li.about').addClass('active');
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>