<?php $__env->startSection('title', 'Minify HTML'); ?>

<?php $__env->startSection('content'); ?>

    <div class="content-minify">
        <div class="container">
            <h2 class="text-center">Minify HTML</h2>
            <p class="text-center">HTML File compression takes the optimization one step further by allowing you to combine the contents of several HTML files into a single file (and minified file). This can be a huge performance benefit when using some SPA frameworks
            </p>

            <div class="row">
                <!--un-minified css code-->
                <div class="col-sm-6">
                    <form action="<?php echo e(url('html-minify')); ?>" method="post">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h3 class="panel-title">Input HTML</h3>
                            </div>
                            <div class="panel-body">
                                <?php if(Session::has('content')): ?>
                                    <textarea name="content_html" required><?php echo e(Session::get('content')); ?></textarea>
                                <?php else: ?>
                                    <textarea name="content_html" autofocus required placeholder="Paste css code here"></textarea>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="text-right">
                            <button type="submit" class="btn btn-info">Minify</button>
                        </div>
                    </form>
                </div>

                <!--minified css code-->
                <div class="col-sm-6">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <h3 class="panel-title">Minified Output</h3>
                        </div>
                        <div class="panel-body">
                            <textarea class="minified_output" placeholder="minified code"><?php if(Session::has('minified')): ?><?php echo e(Session::get('minified')); ?><?php endif; ?></textarea>

                        </div>
                    </div>
                    <div class="text-right">
                        <button type="submit" class="btn btn-info select_text">Select All</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(function () {
            $('.navbar-nav>li').removeClass('active');
            $('.navbar-nav>li.html').addClass('active');
        })
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>