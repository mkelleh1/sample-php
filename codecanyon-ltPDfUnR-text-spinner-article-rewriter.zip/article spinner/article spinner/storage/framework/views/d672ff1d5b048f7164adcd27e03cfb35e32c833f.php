<?php $__env->startSection('content'); ?>

    <div class="container">
        <form action="<?php echo e(url('/article')); ?>" method="POST" class="search-form">
            <?php echo e(csrf_field()); ?>

            <input type="text" name="_token" value="<?php echo e(csrf_token()); ?>">
            <textarea name="css"></textarea>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>